# Problem: Tuples
# HackerRank: https://www.hackerrank.com/challenges/python-tuples/problem

n = int(input())
integer_list = tuple(map(int, input().split()))

print(hash(integer_list))
