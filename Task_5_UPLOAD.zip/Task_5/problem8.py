# Problem: Set .add()
# HackerRank: https://www.hackerrank.com/challenges/py-set-add/problem

n = int(input())
countries = set()

for _ in range(n):
    countries.add(input().strip())

print(len(countries))
